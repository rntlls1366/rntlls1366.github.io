
function bangibangi() {

    document.addEventListener('contextmenu', function (e) {
        e.stopPropagation();
    }, true);

    document.addEventListener('selectstart', function (e) {
        e.stopPropagation();
    }, true);

    document.addEventListener('keydown', function (e) {
        if (e.keyCode === 123) {
            e.stopPropagation();
        }
    }, true);
}

document.addEventListener('DOMContentLoaded', () => {

    chrome.storage.sync.get(['enabled'], (result) => {
        if (result.enabled) {
            bangibangi();
        }
    });
});
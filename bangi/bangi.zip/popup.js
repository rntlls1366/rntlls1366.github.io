document.addEventListener('DOMContentLoaded', () => {
    const toggleSwitch = document.getElementById('toggle-switch');

    chrome.storage.sync.get(['enabled'], (result) => {
        toggleSwitch.checked = result.enabled || false;
    });

    toggleSwitch.addEventListener('change', () => {
        chrome.storage.sync.set({ enabled: toggleSwitch.checked });
    });
});
